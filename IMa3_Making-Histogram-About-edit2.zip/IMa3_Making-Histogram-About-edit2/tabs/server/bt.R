#server
library(reticulate)
library(shinyFiles)

# load the python script to run this page 
source_python('./tabs/server/[Pycharm] IMa3_BrnThn2.py') 


options(shiny.maxRequestSize=30*1024^2)
volumes = getVolumes() # this makes the directory at the base of your computer.
#volumes = c(Documents = "C:/Users")
volumes=c('wd'='.')




observe({
  #shinyFileChoose(input, "input_dir",  roots = c(Documents = "C:/Users"), session = session) �̷��� �ϸ� C:Users���� ���� 
  #shinyFileChoose(input, "input_dir", roots = volumes, session = session) #,filetype=c('ti') 
  shinyFileChoose(input, "input_dir", roots=volumes, session = session)  
  })
  
txt_file <- reactive({
  if(!is.null(input$input_dir)){
    # browser()
    file_selected<-parseFilePaths(volumes, input$input_dir)
    output$txt_file <- renderText(as.character(file_selected$datapath))
    }
    as.character(file_selected$datapath)
    })

#���ϸ� ����
file_selected<-reactive({parseFilePaths(volumes, input$input_dir)
})

output$file_name <- renderText({
  return(paste(as.character(file_selected()$name)))
})

#could not find function "text_file" ��� ������ 
#error in paste: object 'file_selected' not found 
#input$output_dir���� ������ ������ �ȶ����� ���ϸ��� ���� ����
#input$output_name�� ������ �ƿ�ǲ ���� �̸��� ���� 
#input$input_dir �̰� ���� ���� �̻��ϰ� ���� 

save_dir <- reactive({
  slash <- gregexpr('/',txt_file())[[1]]
  substr(txt_file(), 1, slash[length(slash)])
  })
  
output_dir <- reactive({
  paste(save_dir(), input$output_name, sep='')
  })

observeEvent(input$go, {
  dupl <- sum(list.files(path=save_dir())==input$output_name)
  
    if(dupl==0){
      BrnThn(input_dir = txt_file(), out_dir=output_dir() ,Brn=input$Brn, Thn=input$Thn)
      
      #output$out_dir <- renderText(input$output_dir) #input directory
      output$out_dir <- renderText(output_dir()) #output directory
      output$running_mes <- renderText("Check your file")
      
    }else if(dupl!=0){
      output$running_mes <- renderText("The data name you entered is duplicated. Please change the ouput data name")
    }
  })







